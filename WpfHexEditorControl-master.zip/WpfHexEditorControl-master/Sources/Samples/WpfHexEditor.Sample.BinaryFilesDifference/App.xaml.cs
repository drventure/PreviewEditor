﻿using System.Windows;

namespace WpfHexEditor.Sample.BinaryFilesDifference
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
