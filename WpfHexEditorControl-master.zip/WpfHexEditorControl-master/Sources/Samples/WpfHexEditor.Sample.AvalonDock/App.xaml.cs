﻿using System.Windows;

namespace WpfHexEditor.Sample.AvalonDock
{
    /// <summary>
    /// Logique d'interaction pour App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
