﻿' This file is used by Code Analysis to maintain SuppressMessage
' attributes that are applied to this project.
' Project-level suppressions either have no target or are given
' a specific target and scoped to a namespace, type, member, etc.

<Assembly: CodeAnalysis.SuppressMessage("Qualité du code", "IDE0051:Supprimer les membres privés non utilisés", Justification:="<En attente>", Scope:="member", Target:="~M:WpfHexEditor.Sample.VB.My.MyWpfExtension.MyWindows.Create__Instance__``1(``0)~``0")>
<Assembly: CodeAnalysis.SuppressMessage("Qualité du code", "IDE0051:Supprimer les membres privés non utilisés", Justification:="<En attente>", Scope:="member", Target:="~M:WpfHexEditor.Sample.VB.My.MyWpfExtension.MyWindows.Dispose__Instance__``1(``0@)")>
