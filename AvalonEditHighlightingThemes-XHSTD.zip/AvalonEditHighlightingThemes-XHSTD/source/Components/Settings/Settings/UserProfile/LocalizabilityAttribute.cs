﻿using System;

namespace Settings.UserProfile
{
    internal class LocalizabilityAttribute : Attribute
    {
    }
}