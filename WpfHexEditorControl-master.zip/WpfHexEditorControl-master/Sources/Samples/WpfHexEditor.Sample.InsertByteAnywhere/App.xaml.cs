﻿using System.Windows;

namespace WpfHexEditor.Sample.InsertByteAnywhere
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
