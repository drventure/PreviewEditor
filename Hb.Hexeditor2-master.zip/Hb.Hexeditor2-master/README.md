# Hb.Hexeditor2
Hb.Hexeditor2 is a hex editor written in C# uses HexBox2 control.
Project screen shots and Wiki at SourgeForge https://sourceforge.net/projects/hb-hexeditor2/
